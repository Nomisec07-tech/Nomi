neoxr.create(async (m, {
   client,
   prefix,
   Func
}) => {
   try {
      client.reply(m.chat, `🏷️ Upgrade to premium plan only IDR 14,999,- to get 1K limits for 1 month.\n\nIf you want to buy contact *${prefix}owner*`, m)
   } catch (e) {
      client.reply(m.chat, Func.jsonFormat(e), m)
   }
}, {
   usage: ['premium'],
   category: 'miscs'
}, __filename)