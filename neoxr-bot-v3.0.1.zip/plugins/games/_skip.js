neoxr.create(async (m, {
   client,
   command,
   Func
}) => {
   try {
      var id = m.chat
      if (command == 'fiboskip') {
         client.deret = client.deret ? client.deret : {}
         if ((id in client.deret)) return client.reply(m.chat, Func.texted('bold', `✅ Fibonacci game session successfully deleted.`), m).then(() => delete client.deret[id])
      } else if (command == 'skip') {
         client.math = client.math ? client.math : {}
         if ((id in client.math)) return client.reply(m.chat, Func.texted('bold', `✅ Math game session successfully deleted.`), m).then(() => delete client.math[id])
      } else if (command == 'verbskip') {
         client.verb = client.verb ? client.verb : {}
         if ((id in client.verb)) return client.reply(m.chat, Func.texted('bold', `✅ Verb game session successfully deleted.`), m).then(() => delete client.verb[id])
      }
   } catch (e) {
      client.reply(m.chat, Func.jsonFormat(e), m)
   }
}, {
   usage: ['fiboskip', 'skip', 'verbskip'],
   limit: true,
   group: true,
   game: true
}, __filename)